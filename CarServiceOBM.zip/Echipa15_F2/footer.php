<footer class="footer-area section-padding-80-0">
    <div class="container-fluid bg-dark text-light footer pt-5 mt-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container py-5">
            <div class="row g-5">
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-light mb-4">Adresă</h4>
                    <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i>Bulevardul Iuliu Maniu 1-3, București</p>
                    <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>0763 854 122</p>
                    <p class="mb-2"><i class="fa fa-envelope me-3"></i>obama-cars@gmail.com</p>
                    <div class="d-flex pt-2">
                        <a class="btn btn-outline-light btn-social" href="https://www.instagram.com/adriandiaconuu/"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-light mb-4">Program de lucru</h4>
                    <h6 class="text-light">Luni - Vineri:</h6>
                    <p class="mb-4">09:00 -  18:00</p>
                    <h6 class="text-light">Sâmbătă - Duminică:</h6>
                    <p class="mb-0">09:00 -  13:00</p>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-light mb-4">Servicii</h4>
                    <a class="btn btn-link">Diagnoză</a>
                    <a class="btn btn-link">Revizii</a>
                    <a class="btn btn-link">Reparație mecanică</a>
                    <a class="btn btn-link">Electronică auto</a>
					<a class="btn btn-link">Tinichigerie/Vopsitorie</a>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="copyright">
                <div class="row">
                    <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                        &copy; <a class="border-bottom" href="#">ServiceObama</a>  All Right Reserved.</a>
                    </div>
                    <div class="col-md-6 text-center text-md-end">
                        <div class="footer-menu">
                            <a href="index.php">Acasă</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
	<a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
</footer>
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>